"""
Flask Web Application and REST API for Clinic Front Desk Management.
"""
import os
from datetime import datetime, date
from flask import Flask, request, jsonify, render_template, redirect, url_for, flash

from clinic.service import ClinicService
from clinic.conflict import DoubleBookingConflictError
from clinic.cancellation import evaluate_cancellation

app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = os.environ.get("SECRET_KEY", "clinic-super-secret-key-2026")

# Default database
DB_PATH = os.environ.get("CLINIC_DB", "clinic.db")
service = ClinicService(DB_PATH)


# =============================================================================
# WEB UI VIEWS
# =============================================================================

@app.route("/")
def landing_view():
    """Landing page outlining the system, architecture, and features."""
    stats = service.get_clinic_stats()
    return render_template("landing.html", stats=stats)


@app.route("/desk")
def desk_view():
    """Front desk schedule and daily timeline workstation."""
    doctors = service.list_doctors()
    selected_doctor_id = request.args.get("doctor_id", type=int)
    if not selected_doctor_id and doctors:
        selected_doctor_id = doctors[0]["id"]

    date_str = request.args.get("date")
    if not date_str:
        date_str = service.get_clock_time().strftime("%Y-%m-%d")

    day_data = None
    if selected_doctor_id:
        day_data = service.get_doctor_day(selected_doctor_id, date_str)

    stats = service.get_clinic_stats()
    clock_time = service.get_clock_time().strftime("%Y-%m-%d %H:%M")

    return render_template(
        "desk.html",
        doctors=doctors,
        selected_doctor_id=selected_doctor_id,
        selected_date=date_str,
        day_data=day_data,
        stats=stats,
        clock_time=clock_time
    )


@app.route("/search")
def search_view():
    """Search patient appointments by name."""
    query = request.args.get("q", "").strip()
    appointments = []
    if query:
        appointments = service.search_patient_appointments(query)
    return render_template("search.html", query=query, appointments=appointments)


@app.route("/outbox-view")
def outbox_view():
    """Notification Outbox & Clock simulation control center."""
    date_filter = request.args.get("date")
    outbox_items = service.get_outbox(date_str=date_filter)
    clock_time = service.get_clock_time().isoformat()
    return render_template(
        "outbox.html",
        outbox=outbox_items,
        clock_time=clock_time,
        date_filter=date_filter or ""
    )


@app.route("/api-docs")
def api_docs_view():
    """Interactive REST API documentation & endpoint test console."""
    return render_template("api_docs.html")


# =============================================================================
# REST API ENDPOINTS
# =============================================================================

# --- Doctors ---
@app.route("/api/doctors", methods=["GET"])
def api_list_doctors():
    doctors = service.list_doctors()
    return jsonify({"success": True, "doctors": doctors}), 200


@app.route("/api/doctors/<int:doctor_id>/day", methods=["GET"])
def api_doctor_day(doctor_id: int):
    target_date = request.args.get("date") or service.get_clock_time().strftime("%Y-%m-%d")
    try:
        data = service.get_doctor_day(doctor_id, target_date)
        return jsonify({"success": True, **data}), 200
    except ValueError as e:
        return jsonify({"success": False, "error": str(e)}), 404


# --- Appointments Core (Conflict-Free Booking) ---
@app.route("/api/appointments", methods=["GET", "POST"])
def api_appointments():
    if request.method == "POST":
        data = request.get_json(silent=True) or request.form.to_dict()
        doctor_id = data.get("doctor_id")
        patient_name = data.get("patient_name")
        patient_phone = data.get("patient_phone")
        patient_email = data.get("patient_email")
        start_time = data.get("start_time")
        end_time = data.get("end_time")
        duration_minutes = int(data.get("duration_minutes", 30))
        notes = data.get("notes")

        if not doctor_id or not patient_name or not patient_phone or not start_time:
            return jsonify({
                "success": False,
                "error": "Missing required fields: doctor_id, patient_name, patient_phone, start_time are mandatory."
            }), 400

        try:
            doctor_id = int(doctor_id)
            appt = service.book_appointment(
                doctor_id=doctor_id,
                patient_name=patient_name,
                patient_phone=patient_phone,
                start_time=start_time,
                end_time=end_time,
                duration_minutes=duration_minutes,
                patient_email=patient_email,
                notes=notes
            )
            return jsonify({"success": True, "appointment": appt}), 201
        except DoubleBookingConflictError as e:
            return jsonify({
                "success": False,
                "error": str(e),
                "conflicting_appointment": e.conflicting_appointment
            }), 409
        except ValueError as e:
            return jsonify({"success": False, "error": str(e)}), 400
        except Exception as e:
            return jsonify({"success": False, "error": str(e)}), 500

    # GET
    doctor_id = request.args.get("doctor_id", type=int)
    date_str = request.args.get("date")
    status = request.args.get("status")
    patient_query = request.args.get("patient_name") or request.args.get("name")

    if patient_query:
        results = service.search_patient_appointments(patient_query)
    else:
        results = service.list_appointments(doctor_id=doctor_id, date_str=date_str, status=status)

    return jsonify({"success": True, "count": len(results), "appointments": results}), 200


@app.route("/api/appointments/<int:appointment_id>", methods=["GET"])
def api_get_appointment(appointment_id: int):
    appt = service.get_appointment(appointment_id)
    if not appt:
        return jsonify({"success": False, "error": f"Appointment #{appointment_id} not found."}), 404
    return jsonify({"success": True, "appointment": appt}), 200


# --- Fair Cancellation Endpoint ---
@app.route("/api/appointments/<int:appointment_id>/cancel", methods=["POST"])
def api_cancel_appointment(appointment_id: int):
    data = request.get_json(silent=True) or request.form.to_dict() or {}
    cancellation_time = data.get("cancellation_time") or data.get("cancelled_at") or data.get("now")
    reason = data.get("reason")

    try:
        res = service.cancel_appointment(
            appointment_id=appointment_id,
            cancellation_time=cancellation_time,
            reason=reason
        )
        return jsonify({
            "success": True,
            "appointment": res,
            "fee": res.get("cancellation_fee", 0.0),
            "is_late": res.get("is_late", False),
            "policy_description": res.get("policy_description", "")
        }), 200
    except ValueError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


# --- Mark Completed Endpoint ---
@app.route("/api/appointments/<int:appointment_id>/complete", methods=["POST"])
def api_complete_appointment(appointment_id: int):
    try:
        res = service.complete_appointment(appointment_id)
        return jsonify({"success": True, "appointment": res}), 200
    except ValueError as e:
        return jsonify({"success": False, "error": str(e)}), 400


# --- Level 1 ? T6 (lifecycle): Reschedule Appointment ---
@app.route("/api/appointments/<int:appointment_id>/reschedule", methods=["POST", "PUT", "PATCH"])
def api_reschedule_appointment(appointment_id: int):
    """
    Level 1 Twist: Reschedules an appointment to a new time.
    Keeps doctor and patient invariant, re-verifies overlap excluding self.
    """
    data = request.get_json(silent=True) or request.form.to_dict() or {}
    new_start = data.get("new_start_time") or data.get("start_time")
    new_end = data.get("new_end_time") or data.get("end_time")
    duration = data.get("duration_minutes")
    if duration:
        duration = int(duration)

    if not new_start:
        return jsonify({
            "success": False,
            "error": "Missing new_start_time parameter."
        }), 400

    try:
        res = service.reschedule_appointment(
            appointment_id=appointment_id,
            new_start_time=new_start,
            new_end_time=new_end,
            duration_minutes=duration
        )
        return jsonify({"success": True, "appointment": res}), 200
    except DoubleBookingConflictError as e:
        return jsonify({
            "success": False,
            "error": str(e),
            "conflicting_appointment": e.conflicting_appointment
        }), 409
    except ValueError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


# --- Desk Lookups: Patient Name Search ---
@app.route("/api/appointments/search", methods=["GET"])
def api_search_appointments():
    query = request.args.get("name") or request.args.get("q") or request.args.get("patient_name") or ""
    results = service.search_patient_appointments(query)
    return jsonify({
        "success": True,
        "query": query,
        "count": len(results),
        "appointments": results
    }), 200


# --- Level 2 (T1 integrate) & Level 3 (T2 automation): /clock & /outbox ---
@app.route("/clock", methods=["POST"])
def api_clock():
    """
    Advancement of system clock:
    - Level 2 (T1): Dispatches morning reminders for today's active appointments into /outbox.
    - Level 3 (T2): Auto-marks appointments as no-show 30 min after start if not completed.
    """
    data = request.get_json(silent=True) or request.form.to_dict() or {}
    target_date = data.get("date") or request.args.get("date")
    timestamp = data.get("timestamp") or data.get("now") or data.get("datetime") or request.args.get("timestamp")
    time_str = data.get("time") or request.args.get("time")

    try:
        res = service.tick_clock(target_date=target_date, timestamp=timestamp, time_str=time_str)
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400


@app.route("/outbox", methods=["GET", "DELETE"])
def api_outbox():
    """
    Level 2 (T1): Notification Service Outbox.
    - GET: Retrieves queued notifications.
    - DELETE: Clears notification outbox.
    """
    if request.method == "DELETE":
        service.clear_outbox()
        return jsonify({"success": True, "message": "Notification outbox cleared successfully."}), 200

    target_date = request.args.get("date")
    recipient = request.args.get("recipient")
    items = service.get_outbox(date_str=target_date, recipient=recipient)
    return jsonify({
        "success": True,
        "count": len(items),
        "outbox": items
    }), 200


# --- Level 3 (T2 automation): Dedicated Job Runner ---
@app.route("/api/jobs/no-show", methods=["POST"])
def api_job_no_show():
    data = request.get_json(silent=True) or {}
    clock_time = data.get("timestamp") or data.get("now")
    res = service.tick_clock(timestamp=clock_time)
    return jsonify({
        "success": True,
        "no_shows_marked": res["no_shows_marked"],
        "no_show_appointment_ids": res["no_show_appointment_ids"],
        "clock_time": res["clock_time"]
    }), 200


# --- Overall Stats ---
@app.route("/api/stats", methods=["GET"])
def api_stats():
    return jsonify({"success": True, "stats": service.get_clinic_stats()}), 200


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"Starting Clinic Front Desk Server on http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=True)
