// CuraDesk Front Desk JavaScript Client

function showToast(msg, type = 'success') {
    const container = document.getElementById('toast-container');
    if (!container) return;
    container.className = `mb-6 p-4 rounded-xl text-sm font-medium border ${
        type === 'success' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-rose-50 text-rose-800 border-rose-200'
    }`;
    container.innerText = msg;
    container.classList.remove('hidden');
    setTimeout(() => {
        container.classList.add('hidden');
    }, 5000);
}

// --- BOOK MODAL ---
function openBookModal() {
    document.getElementById('bookModalError').classList.add('hidden');
    document.getElementById('bookModal').classList.remove('hidden');
}

function closeBookModal() {
    document.getElementById('bookModal').classList.add('hidden');
}

async function handleBookSubmit(e) {
    e.preventDefault();
    const errorDiv = document.getElementById('bookModalError');
    errorDiv.classList.add('hidden');

    const doctorId = document.getElementById('book_doctor_id').value;
    const patientName = document.getElementById('book_patient_name').value;
    const patientPhone = document.getElementById('book_patient_phone').value;
    const patientEmail = document.getElementById('book_patient_email').value;
    const bookDate = document.getElementById('book_date').value;
    const bookTime = document.getElementById('book_time').value;
    const duration = parseInt(document.getElementById('book_duration').value);
    const notes = document.getElementById('book_notes').value;

    const startTime = `${bookDate}T${bookTime}:00`;

    try {
        const res = await fetch('/api/appointments', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                doctor_id: parseInt(doctorId),
                patient_name: patientName,
                patient_phone: patientPhone,
                patient_email: patientEmail,
                start_time: startTime,
                duration_minutes: duration,
                notes: notes
            })
        });

        const data = await res.json();
        if (res.status === 201 && data.success) {
            closeBookModal();
            window.location.reload();
        } else if (res.status === 409) {
            errorDiv.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5"></i> <strong>Double-Booking Conflict:</strong> ${data.error}`;
            errorDiv.classList.remove('hidden');
        } else {
            errorDiv.innerText = data.error || 'Failed to book appointment.';
            errorDiv.classList.remove('hidden');
        }
    } catch (err) {
        errorDiv.innerText = 'Network error: ' + err.message;
        errorDiv.classList.remove('hidden');
    }
}

// --- RESCHEDULE MODAL (LEVEL 1 TWIST) ---
function openRescheduleModal(id, patientName, startIso, endIso) {
    document.getElementById('rescheduleModalError').classList.add('hidden');
    document.getElementById('resched_id').value = id;
    document.getElementById('resched_patient').innerText = patientName;
    document.getElementById('resched_current_slot').innerText = `${startIso.substring(0, 10)} (${startIso.substring(11, 16)} - ${endIso.substring(11, 16)})`;

    document.getElementById('resched_date').value = startIso.substring(0, 10);
    document.getElementById('resched_time').value = startIso.substring(11, 16);
    document.getElementById('rescheduleModal').classList.remove('hidden');
}

function closeRescheduleModal() {
    document.getElementById('rescheduleModal').classList.add('hidden');
}

async function handleRescheduleSubmit(e) {
    e.preventDefault();
    const errorDiv = document.getElementById('rescheduleModalError');
    errorDiv.classList.add('hidden');

    const apptId = document.getElementById('resched_id').value;
    const newDate = document.getElementById('resched_date').value;
    const newTime = document.getElementById('resched_time').value;
    const duration = parseInt(document.getElementById('resched_duration').value);

    const newStart = `${newDate}T${newTime}:00`;

    try {
        const res = await fetch(`/api/appointments/${apptId}/reschedule`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                new_start_time: newStart,
                duration_minutes: duration
            })
        });

        const data = await res.json();
        if (res.status === 200 && data.success) {
            closeRescheduleModal();
            window.location.reload();
        } else if (res.status === 409) {
            errorDiv.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1.5"></i> <strong>Schedule Conflict:</strong> ${data.error}`;
            errorDiv.classList.remove('hidden');
        } else {
            errorDiv.innerText = data.error || 'Failed to reschedule.';
            errorDiv.classList.remove('hidden');
        }
    } catch (err) {
        errorDiv.innerText = 'Network error: ' + err.message;
        errorDiv.classList.remove('hidden');
    }
}

// --- FAIR CANCELLATION MODAL ---
let targetStartTime = null;

function openCancelModal(id, patientName, startIso) {
    document.getElementById('cancelModalError').classList.add('hidden');
    document.getElementById('cancel_id').value = id;
    document.getElementById('cancel_patient').innerText = patientName;
    document.getElementById('cancel_time_display').innerText = `${startIso.substring(0, 10)} at ${startIso.substring(11, 16)}`;

    targetStartTime = new Date(startIso);
    const now = new Date();
    const diffHours = (targetStartTime - now) / (1000 * 60 * 60);

    const feePreview = document.getElementById('cancelFeePreview');
    if (diffHours >= 24) {
        feePreview.className = "p-3.5 rounded-xl border bg-emerald-50 text-emerald-800 border-emerald-200 text-xs";
        feePreview.innerHTML = `
            <div class="font-bold flex items-center"><i class="fa-solid fa-circle-check mr-1.5"></i> Eligible for 100% FREE Cancellation</div>
            <div class="mt-1 text-slate-600">Notice provided: ~${Math.round(diffHours)} hours in advance (policy cutoff is 24 hours). Fee assessed: <strong>$0.00</strong>.</div>
        `;
    } else {
        feePreview.className = "p-3.5 rounded-xl border bg-amber-50 text-amber-800 border-amber-200 text-xs";
        feePreview.innerHTML = `
            <div class="font-bold flex items-center"><i class="fa-solid fa-triangle-exclamation mr-1.5"></i> Late Cancellation Policy Applies</div>
            <div class="mt-1 text-slate-600">Notice provided is less than 24 hours prior to appointment. A small fair fee of <strong>$25.00</strong> will be charged.</div>
        `;
    }

    document.getElementById('cancelModal').classList.remove('hidden');
}

function closeCancelModal() {
    document.getElementById('cancelModal').classList.add('hidden');
}

async function handleCancelSubmit(e) {
    e.preventDefault();
    const errorDiv = document.getElementById('cancelModalError');
    errorDiv.classList.add('hidden');

    const apptId = document.getElementById('cancel_id').value;
    const reason = document.getElementById('cancel_reason').value;

    try {
        const res = await fetch(`/api/appointments/${apptId}/cancel`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ reason: reason })
        });

        const data = await res.json();
        if (res.status === 200 && data.success) {
            closeCancelModal();
            window.location.reload();
        } else {
            errorDiv.innerText = data.error || 'Failed to cancel appointment.';
            errorDiv.classList.remove('hidden');
        }
    } catch (err) {
        errorDiv.innerText = 'Network error: ' + err.message;
        errorDiv.classList.remove('hidden');
    }
}

// --- COMPLETE APPOINTMENT ---
async function completeAppointment(id) {
    if (!confirm('Mark this appointment as Completed?')) return;
    try {
        const res = await fetch(`/api/appointments/${id}/complete`, { method: 'POST' });
        const data = await res.json();
        if (data.success) {
            window.location.reload();
        } else {
            alert('Error: ' + data.error);
        }
    } catch (err) {
        alert('Network error: ' + err.message);
    }
}
