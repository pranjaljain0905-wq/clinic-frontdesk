from datetime import datetime
import pytest
from clinic.conflict import DoubleBookingConflictError


def test_book_valid_appointment(service_env):
    appt = service_env.book_appointment(
        doctor_id=1,
        patient_name="Eleanor Vance",
        patient_phone="555-0199",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00",
        notes="First checkup"
    )
    assert appt["id"] is not None
    assert appt["doctor_id"] == 1
    assert appt["patient_name"] == "Eleanor Vance"
    assert appt["status"] == "booked"


def test_prevent_exact_double_booking(service_env):
    # Book first patient
    service_env.book_appointment(
        doctor_id=1,
        patient_name="Patient One",
        patient_phone="555-0001",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00"
    )

    # Attempt to book second patient in the exact same slot for same doctor
    with pytest.raises(DoubleBookingConflictError) as exc_info:
        service_env.book_appointment(
            doctor_id=1,
            patient_name="Patient Two",
            patient_phone="555-0002",
            start_time="2026-10-15T09:00:00",
            end_time="2026-10-15T09:30:00"
        )
    assert "already has an overlapping appointment" in str(exc_info.value)


def test_prevent_partial_overlaps(service_env):
    # Anchor appointment: 10:00 to 11:00
    service_env.book_appointment(
        doctor_id=2,
        patient_name="Anchor Patient",
        patient_phone="555-1000",
        start_time="2026-10-15T10:00:00",
        end_time="2026-10-15T11:00:00"
    )

    # 1. Overlap starting before, ending inside (09:30 - 10:30)
    with pytest.raises(DoubleBookingConflictError):
        service_env.book_appointment(
            doctor_id=2,
            patient_name="Overlap Left",
            patient_phone="555-1001",
            start_time="2026-10-15T09:30:00",
            end_time="2026-10-15T10:30:00"
        )

    # 2. Overlap starting inside, ending after (10:30 - 11:30)
    with pytest.raises(DoubleBookingConflictError):
        service_env.book_appointment(
            doctor_id=2,
            patient_name="Overlap Right",
            patient_phone="555-1002",
            start_time="2026-10-15T10:30:00",
            end_time="2026-10-15T11:30:00"
        )

    # 3. Overlap completely enclosed (10:15 - 10:45)
    with pytest.raises(DoubleBookingConflictError):
        service_env.book_appointment(
            doctor_id=2,
            patient_name="Enclosed",
            patient_phone="555-1003",
            start_time="2026-10-15T10:15:00",
            end_time="2026-10-15T10:45:00"
        )

    # 4. Overlap completely enclosing (09:00 - 12:00)
    with pytest.raises(DoubleBookingConflictError):
        service_env.book_appointment(
            doctor_id=2,
            patient_name="Enclosing",
            patient_phone="555-1004",
            start_time="2026-10-15T09:00:00",
            end_time="2026-10-15T12:00:00"
        )


def test_allow_back_to_back_touching_boundary(service_env):
    # Appt 1: 09:00 to 09:30
    appt1 = service_env.book_appointment(
        doctor_id=3,
        patient_name="Morning Patient",
        patient_phone="555-2001",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00"
    )
    # Appt 2 starts at exactly 09:30 (touching boundary)
    appt2 = service_env.book_appointment(
        doctor_id=3,
        patient_name="Next Patient",
        patient_phone="555-2002",
        start_time="2026-10-15T09:30:00",
        end_time="2026-10-15T10:00:00"
    )
    assert appt1["id"] is not None
    assert appt2["id"] is not None
    assert appt1["end_time"] == appt2["start_time"]


def test_allow_parallel_appointments_different_doctors(service_env):
    # Doctor 1: 09:00 - 09:30
    appt_doc1 = service_env.book_appointment(
        doctor_id=1,
        patient_name="Cardio Patient",
        patient_phone="555-3001",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00"
    )
    # Doctor 2: exact same time 09:00 - 09:30
    appt_doc2 = service_env.book_appointment(
        doctor_id=2,
        patient_name="General Patient",
        patient_phone="555-3002",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00"
    )
    assert appt_doc1["id"] != appt_doc2["id"]


def test_cancelled_appointment_frees_slot(service_env):
    # 1. Book initial appointment
    appt = service_env.book_appointment(
        doctor_id=1,
        patient_name="Will Cancel",
        patient_phone="555-4001",
        start_time="2026-10-15T14:00:00",
        end_time="2026-10-15T14:30:00"
    )

    # 2. Cancel it
    service_env.cancel_appointment(appt["id"], cancellation_time="2026-10-13T10:00:00")

    # 3. New patient books the same slot -> must succeed without conflict!
    new_appt = service_env.book_appointment(
        doctor_id=1,
        patient_name="New Patient Grabbing Slot",
        patient_phone="555-4002",
        start_time="2026-10-15T14:00:00",
        end_time="2026-10-15T14:30:00"
    )
    assert new_appt["id"] != appt["id"]
    assert new_appt["status"] == "booked"


def test_validation_errors(service_env):
    # Missing name
    with pytest.raises(ValueError):
        service_env.book_appointment(
            doctor_id=1,
            patient_name="",
            patient_phone="555-9999",
            start_time="2026-10-15T10:00:00"
        )

    # Invalid doctor
    with pytest.raises(ValueError):
        service_env.book_appointment(
            doctor_id=9999,
            patient_name="Test",
            patient_phone="555-9999",
            start_time="2026-10-15T10:00:00"
        )

    # Start >= End
    with pytest.raises(ValueError):
        service_env.book_appointment(
            doctor_id=1,
            patient_name="Test",
            patient_phone="555-9999",
            start_time="2026-10-15T10:00:00",
            end_time="2026-10-15T09:30:00"
        )
