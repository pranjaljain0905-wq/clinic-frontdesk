import sys
from pathlib import Path

# Ensure root directory is on sys.path
root_dir = str(Path(__file__).resolve().parent.parent)
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

import pytest
from clinic.service import ClinicService
from web.app import app
import web.app as web_module


@pytest.fixture
def service_env(tmp_path):
    test_db = str(tmp_path / "test_clinic.db")
    svc = ClinicService(test_db)
    web_module.service = svc
    app.config["TESTING"] = True
    return svc


@pytest.fixture
def client(service_env):
    with app.test_client() as c:
        yield c
