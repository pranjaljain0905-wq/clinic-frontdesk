import pytest
from datetime import datetime


def test_fair_cancellation_in_good_time(service_env):
    # Appointment on 2026-10-15 at 10:00 AM
    appt = service_env.book_appointment(
        doctor_id=1,
        patient_name="Punctual Pete",
        patient_phone="555-5001",
        start_time="2026-10-15T10:00:00",
        end_time="2026-10-15T10:30:00"
    )

    # Cancelled on 2026-10-13 at 10:00 AM (48 hours before start -> >= 24h cutoff)
    res = service_env.cancel_appointment(
        appointment_id=appt["id"],
        cancellation_time="2026-10-13T10:00:00",
        reason="Plans changed with ample notice"
    )

    assert res["status"] == "cancelled"
    assert res["cancellation_fee"] == 0.0
    assert res["is_late"] is False
    assert "On-time cancellation" in res["policy_description"]


def test_fair_cancellation_exact_cutoff_boundary(service_env):
    # Appointment on 2026-10-15 at 10:00 AM
    appt = service_env.book_appointment(
        doctor_id=1,
        patient_name="Boundary Bob",
        patient_phone="555-5002",
        start_time="2026-10-15T10:00:00",
        end_time="2026-10-15T10:30:00"
    )

    # Cancelled on 2026-10-14 at 10:00 AM (exactly 24.0 hours before start)
    res = service_env.cancel_appointment(
        appointment_id=appt["id"],
        cancellation_time="2026-10-14T10:00:00"
    )
    assert res["status"] == "cancelled"
    assert res["cancellation_fee"] == 0.0
    assert res["is_late"] is False


def test_fair_cancellation_late_fee(service_env):
    # Appointment on 2026-10-15 at 10:00 AM
    appt = service_env.book_appointment(
        doctor_id=1,
        patient_name="Late Larry",
        patient_phone="555-5003",
        start_time="2026-10-15T10:00:00",
        end_time="2026-10-15T10:30:00"
    )

    # Cancelled on 2026-10-15 at 07:00 AM (only 3 hours before start -> < 24h)
    res = service_env.cancel_appointment(
        appointment_id=appt["id"],
        cancellation_time="2026-10-15T07:00:00",
        reason="Woke up with an emergency"
    )

    assert res["status"] == "cancelled"
    assert res["cancellation_fee"] == 25.00
    assert res["is_late"] is True
    assert "Late cancellation" in res["policy_description"]


def test_cancellation_after_appointment_start_time(service_env):
    appt = service_env.book_appointment(
        doctor_id=2,
        patient_name="Post Start Paula",
        patient_phone="555-5004",
        start_time="2026-10-15T10:00:00",
        end_time="2026-10-15T10:30:00"
    )

    # Cancelled at 10:10 AM (after start)
    res = service_env.cancel_appointment(
        appointment_id=appt["id"],
        cancellation_time="2026-10-15T10:10:00"
    )
    assert res["status"] == "cancelled"
    assert res["cancellation_fee"] == 25.00
    assert res["is_late"] is True


def test_cannot_cancel_already_cancelled_appointment(service_env):
    appt = service_env.book_appointment(
        doctor_id=1,
        patient_name="Double Cancel Dave",
        patient_phone="555-5005",
        start_time="2026-10-15T12:00:00",
        end_time="2026-10-15T12:30:00"
    )

    service_env.cancel_appointment(appt["id"], cancellation_time="2026-10-10T12:00:00")

    with pytest.raises(ValueError) as exc:
        service_env.cancel_appointment(appt["id"], cancellation_time="2026-10-11T12:00:00")
    assert "already cancelled" in str(exc.value)
