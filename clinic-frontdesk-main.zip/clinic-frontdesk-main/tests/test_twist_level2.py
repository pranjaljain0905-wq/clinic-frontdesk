import pytest


def test_level2_morning_reminders_graded_via_outbox_after_clock(client, service_env):
    # Set up appointments:
    # 1. Active today (2026-10-15) for Dr. 1
    service_env.book_appointment(
        doctor_id=1,
        patient_name="Anita Roy",
        patient_phone="9811111111",
        start_time="2026-10-15T09:30:00",
        end_time="2026-10-15T10:00:00"
    )

    # 2. Active today (2026-10-15) for Dr. 2
    service_env.book_appointment(
        doctor_id=2,
        patient_name="Sunil Mittal",
        patient_phone="9822222222",
        start_time="2026-10-15T11:00:00",
        end_time="2026-10-15T11:30:00"
    )

    # 3. Tomorrow's appointment (2026-10-16) - should NOT receive today's reminder
    service_env.book_appointment(
        doctor_id=1,
        patient_name="Tomorrow Tom",
        patient_phone="9833333333",
        start_time="2026-10-16T09:30:00",
        end_time="2026-10-16T10:00:00"
    )

    # 4. Cancelled appointment today - should NOT receive reminder
    cancelled_appt = service_env.book_appointment(
        doctor_id=1,
        patient_name="Cancelled Carl",
        patient_phone="9844444444",
        start_time="2026-10-15T14:00:00",
        end_time="2026-10-15T14:30:00"
    )
    service_env.cancel_appointment(cancelled_appt["id"], cancellation_time="2026-10-14T10:00:00")

    # Clear outbox first
    r_del = client.delete("/outbox")
    assert r_del.status_code == 200

    # 1. Trigger POST /clock for a day with no appointments -> 0 notifications
    r_empty_day = client.post("/clock", json={"date": "2026-10-10"})
    assert r_empty_day.status_code == 200
    assert r_empty_day.json["dispatched_count"] == 0

    # 2. Trigger POST /clock for today 2026-10-15
    r_clock = client.post("/clock", json={"date": "2026-10-15"})
    assert r_clock.status_code == 200
    data = r_clock.json
    assert data["success"] is True
    assert data["dispatched_count"] == 2
    assert data["reminders_dispatched"] == 2

    # 3. Verify GET /outbox
    r_outbox = client.get("/outbox")
    assert r_outbox.status_code == 200
    outbox_json = r_outbox.json
    assert outbox_json["success"] is True
    assert outbox_json["count"] == 2

    recipients = [item["recipient"] for item in outbox_json["outbox"]]
    assert "9811111111" in recipients  # Anita Roy
    assert "9822222222" in recipients  # Sunil Mittal
    assert "9833333333" not in recipients  # Tomorrow Tom
    assert "9844444444" not in recipients  # Cancelled Carl

    # Check notification content details
    anita_notif = next(item for item in outbox_json["outbox"] if item["recipient"] == "9811111111")
    assert anita_notif["patient_name"] == "Anita Roy"
    assert anita_notif["doctor_name"] == "Dr. Sarah Jenkins"
    assert "09:30" in anita_notif["message"]

    # 4. Test Idempotency: Calling POST /clock again for the same day does not duplicate
    r_clock_again = client.post("/clock", json={"date": "2026-10-15"})
    assert r_clock_again.status_code == 200
    assert r_clock_again.json["reminders_dispatched"] == 0

    # Outbox count remains 2
    r_outbox2 = client.get("/outbox")
    assert r_outbox2.json["count"] == 2

    # 5. Clear outbox via DELETE /outbox
    r_clear = client.delete("/outbox")
    assert r_clear.status_code == 200
    assert client.get("/outbox").json["count"] == 0
