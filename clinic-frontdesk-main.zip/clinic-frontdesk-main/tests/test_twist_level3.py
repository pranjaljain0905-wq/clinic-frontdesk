import pytest


def test_level3_noshow_automation_graded_via_post_clock(client, service_env):
    # Appt 1: 10:00 - 10:30 on 2026-10-15
    appt1 = service_env.book_appointment(
        doctor_id=1,
        patient_name="Forgetful Fred",
        patient_phone="9855555555",
        start_time="2026-10-15T10:00:00",
        end_time="2026-10-15T10:30:00"
    )

    # 1. Clock at 10:15 (15 min after start -> < 30m elapsed)
    r1 = client.post("/clock", json={"timestamp": "2026-10-15T10:15:00"})
    assert r1.status_code == 200
    assert r1.json["no_shows_marked"] == 0

    # Verify status is still booked
    check1 = service_env.get_appointment(appt1["id"])
    assert check1["status"] == "booked"

    # 2. Clock at 10:30 (exactly 30 min after start -> >= 30m elapsed)
    r2 = client.post("/clock", json={"timestamp": "2026-10-15T10:30:00"})
    assert r2.status_code == 200
    assert r2.json["no_shows_marked"] == 1
    assert appt1["id"] in r2.json["no_show_appointment_ids"]

    # Verify status is now 'no_show'
    check2 = service_env.get_appointment(appt1["id"])
    assert check2["status"] == "no_show"
    assert "did not attend within 30 minutes" in check2["cancellation_reason"]


def test_level3_completed_appointments_not_marked_noshow(client, service_env):
    # Appt: 09:00 - 09:30
    appt = service_env.book_appointment(
        doctor_id=1,
        patient_name="Attended Alice",
        patient_phone="9866666666",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00"
    )

    # Doctor marks completed at 09:20
    service_env.complete_appointment(appt["id"])

    # Clock advances to 10:00 (60 minutes after start)
    r = client.post("/clock", json={"timestamp": "2026-10-15T10:00:00"})
    assert r.status_code == 200
    assert appt["id"] not in r.json["no_show_appointment_ids"]

    # Remains completed
    check = service_env.get_appointment(appt["id"])
    assert check["status"] == "completed"


def test_level3_cancelled_appointments_not_marked_noshow(client, service_env):
    # Appt: 09:00 - 09:30
    appt = service_env.book_appointment(
        doctor_id=1,
        patient_name="Cancelled Cindy",
        patient_phone="9877777777",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00"
    )

    # Cancelled before start
    service_env.cancel_appointment(appt["id"], cancellation_time="2026-10-14T09:00:00")

    # Clock advances to 10:00
    r = client.post("/clock", json={"timestamp": "2026-10-15T10:00:00"})
    assert r.status_code == 200
    assert appt["id"] not in r.json["no_show_appointment_ids"]

    # Remains cancelled
    check = service_env.get_appointment(appt["id"])
    assert check["status"] == "cancelled"


def test_level3_multi_appointment_thresholds(client, service_env):
    # Appt A: 09:00 - 09:30
    appt_a = service_env.book_appointment(
        doctor_id=1,
        patient_name="Patient A",
        patient_phone="555-0010",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00"
    )
    # Appt B: 09:15 - 09:45
    appt_b = service_env.book_appointment(
        doctor_id=2,  # different doctor
        patient_name="Patient B",
        patient_phone="555-0020",
        start_time="2026-10-15T09:15:00",
        end_time="2026-10-15T09:45:00"
    )
    # Appt C: 10:00 - 10:30
    appt_c = service_env.book_appointment(
        doctor_id=1,
        patient_name="Patient C",
        patient_phone="555-0030",
        start_time="2026-10-15T10:00:00",
        end_time="2026-10-15T10:30:00"
    )

    # Clock at 09:40:
    # Appt A: elapsed = 40 min >= 30 min -> no_show!
    # Appt B: elapsed = 25 min < 30 min -> stays booked!
    # Appt C: not started -> stays booked!
    r = client.post("/clock", json={"timestamp": "2026-10-15T09:40:00"})
    assert r.status_code == 200
    assert r.json["no_shows_marked"] == 1
    assert r.json["no_show_appointment_ids"] == [appt_a["id"]]

    assert service_env.get_appointment(appt_a["id"])["status"] == "no_show"
    assert service_env.get_appointment(appt_b["id"])["status"] == "booked"
    assert service_env.get_appointment(appt_c["id"])["status"] == "booked"
