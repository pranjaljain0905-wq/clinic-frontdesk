import pytest


def test_landing_page_renders_cleanly(client):
    res = client.get("/")
    assert res.status_code == 200
    html = res.data.decode("utf-8")
    assert "Never Double-Book a Doctor" in html
    assert "The Front Desk's Frustrations are the Spec" in html
    assert "Three Official Challenge Twists" in html
    assert "Three Features We Would Build Next" in html


def test_desk_view_renders_doctor_and_slots(client, service_env):
    service_env.book_appointment(
        doctor_id=1,
        patient_name="Desk View Patient",
        patient_phone="555-4321",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00"
    )
    res = client.get("/desk?doctor_id=1&date=2026-10-15")
    assert res.status_code == 200
    html = res.data.decode("utf-8")
    assert "Doctor's Day Schedule" in html
    assert "Dr. Sarah Jenkins" in html
    assert "Desk View Patient" in html


def test_search_view_and_api(client, service_env):
    service_env.book_appointment(
        doctor_id=2,
        patient_name="Sherlock Holmes",
        patient_phone="555-221B",
        start_time="2026-10-15T10:00:00",
        end_time="2026-10-15T10:30:00"
    )

    # Web view search
    r_web = client.get("/search?q=Holmes")
    assert r_web.status_code == 200
    assert "Sherlock Holmes" in r_web.data.decode("utf-8")

    # API search
    r_api = client.get("/api/appointments/search?name=sherlock")
    assert r_api.status_code == 200
    assert r_api.json["count"] == 1
    assert r_api.json["appointments"][0]["patient_name"] == "Sherlock Holmes"


def test_api_doctors_list_and_day(client):
    r_docs = client.get("/api/doctors")
    assert r_docs.status_code == 200
    assert len(r_docs.json["doctors"]) == 4

    r_day = client.get("/api/doctors/1/day?date=2026-10-15")
    assert r_day.status_code == 200
    assert r_day.json["doctor"]["id"] == 1
    assert "appointments" in r_day.json
    assert "stats" in r_day.json


def test_api_booking_and_conflict_http_codes(client):
    payload1 = {
        "doctor_id": 1,
        "patient_name": "API Patient 1",
        "patient_phone": "555-8801",
        "start_time": "2026-10-15T15:00:00",
        "duration_minutes": 30
    }
    r1 = client.post("/api/appointments", json=payload1)
    assert r1.status_code == 201
    assert r1.json["success"] is True
    appt_id = r1.json["appointment"]["id"]

    # Attempt conflicting booking
    payload2 = {
        "doctor_id": 1,
        "patient_name": "API Patient 2",
        "patient_phone": "555-8802",
        "start_time": "2026-10-15T15:15:00",
        "duration_minutes": 30
    }
    r2 = client.post("/api/appointments", json=payload2)
    assert r2.status_code == 409
    assert r2.json["success"] is False
    assert "already has an overlapping appointment" in r2.json["error"]


def test_api_reschedule_endpoint(client, service_env):
    appt = service_env.book_appointment(
        doctor_id=1,
        patient_name="Reschedule API Test",
        patient_phone="555-7701",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00"
    )

    r = client.post(f"/api/appointments/{appt['id']}/reschedule", json={
        "new_start_time": "2026-10-15T16:00:00",
        "duration_minutes": 30
    })
    assert r.status_code == 200
    assert r.json["appointment"]["start_time"] == "2026-10-15T16:00:00"


def test_api_cancel_endpoint(client, service_env):
    appt = service_env.book_appointment(
        doctor_id=1,
        patient_name="Cancel API Test",
        patient_phone="555-7702",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00"
    )

    # Cancel with late fee
    r = client.post(f"/api/appointments/{appt['id']}/cancel", json={
        "cancellation_time": "2026-10-15T07:00:00",
        "reason": "Late cancellation test"
    })
    assert r.status_code == 200
    assert r.json["fee"] == 25.0
    assert r.json["is_late"] is True


def test_api_complete_endpoint(client, service_env):
    appt = service_env.book_appointment(
        doctor_id=1,
        patient_name="Complete API Test",
        patient_phone="555-7703",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00"
    )

    r = client.post(f"/api/appointments/{appt['id']}/complete")
    assert r.status_code == 200
    assert r.json["appointment"]["status"] == "completed"


def test_api_stats_endpoint(client):
    r = client.get("/api/stats")
    assert r.status_code == 200
    assert "stats" in r.json
    assert r.json["stats"]["doctors_count"] == 4
