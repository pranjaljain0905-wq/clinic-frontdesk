import pytest


def test_doctor_day_schedule_sorted_and_metrics(service_env):
    # Book 3 appointments in non-chronological order
    a2 = service_env.book_appointment(
        doctor_id=1,
        patient_name="Patient Two",
        patient_phone="555-1002",
        start_time="2026-10-15T11:00:00",
        end_time="2026-10-15T11:30:00"
    )
    a1 = service_env.book_appointment(
        doctor_id=1,
        patient_name="Patient One",
        patient_phone="555-1001",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00"
    )
    a3 = service_env.book_appointment(
        doctor_id=1,
        patient_name="Patient Three",
        patient_phone="555-1003",
        start_time="2026-10-15T14:00:00",
        end_time="2026-10-15T14:30:00"
    )

    # Cancel a3 with late fee
    service_env.cancel_appointment(a3["id"], cancellation_time="2026-10-15T10:00:00")

    # Complete a1
    service_env.complete_appointment(a1["id"])

    # Query Doctor 1's day for 2026-10-15
    day = service_env.get_doctor_day(doctor_id=1, target_date="2026-10-15")

    assert day["doctor"]["name"] == "Dr. Sarah Jenkins"
    assert day["date"] == "2026-10-15"
    assert len(day["appointments"]) == 3

    # Must be sorted chronologically by start_time
    times = [appt["start_time"] for appt in day["appointments"]]
    assert times == sorted(times)
    assert day["appointments"][0]["id"] == a1["id"]
    assert day["appointments"][1]["id"] == a2["id"]
    assert day["appointments"][2]["id"] == a3["id"]

    # Verify metrics
    stats = day["stats"]
    assert stats["total"] == 3
    assert stats["completed"] == 1
    assert stats["booked"] == 1
    assert stats["cancelled"] == 1
    assert stats["cancellation_fees_collected"] == 25.0


def test_doctor_day_empty_day(service_env):
    day = service_env.get_doctor_day(doctor_id=2, target_date="2026-12-25")
    assert len(day["appointments"]) == 0
    assert day["stats"]["total"] == 0
    assert day["stats"]["booked"] == 0


def test_search_patient_appointments_by_name(service_env):
    # Book appointments for patient with partial names
    service_env.book_appointment(
        doctor_id=1,
        patient_name="Eleanor Vance",
        patient_phone="555-9001",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00"
    )
    service_env.book_appointment(
        doctor_id=2,
        patient_name="Alexander Vance",
        patient_phone="555-9002",
        start_time="2026-10-16T10:00:00",
        end_time="2026-10-16T10:30:00"
    )
    service_env.book_appointment(
        doctor_id=1,
        patient_name="Sarah Connor",
        patient_phone="555-9003",
        start_time="2026-10-15T10:00:00",
        end_time="2026-10-15T10:30:00"
    )

    # 1. Search "vance" (case-insensitive) -> matches Eleanor Vance and Alexander Vance
    res_vance = service_env.search_patient_appointments("vance")
    assert len(res_vance) == 2
    names = [r["patient_name"] for r in res_vance]
    assert "Eleanor Vance" in names
    assert "Alexander Vance" in names

    # 2. Search "eleanor" -> 1 match
    res_eleanor = service_env.search_patient_appointments("ELEANOR")
    assert len(res_eleanor) == 1
    assert res_eleanor[0]["patient_name"] == "Eleanor Vance"

    # 3. Search non-existent
    res_none = service_env.search_patient_appointments("Nobody")
    assert len(res_none) == 0

    # 4. Search empty query
    assert len(service_env.search_patient_appointments("")) == 0
    assert len(service_env.search_patient_appointments("   ")) == 0
