import pytest
from clinic.conflict import DoubleBookingConflictError


def test_reschedule_to_open_slot_preserves_doctor_and_patient(service_env):
    # Book initial appointment for Dr. 1
    appt = service_env.book_appointment(
        doctor_id=1,
        patient_name="Clara Oswald",
        patient_phone="555-8888",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00",
        notes="First visit"
    )

    # Reschedule to 14:00 - 14:30 on the same day
    resched = service_env.reschedule_appointment(
        appointment_id=appt["id"],
        new_start_time="2026-10-15T14:00:00",
        new_end_time="2026-10-15T14:30:00"
    )

    # Doctor and patient must remain strictly invariant
    assert resched["id"] == appt["id"]
    assert resched["doctor_id"] == appt["doctor_id"]
    assert resched["patient_name"] == "Clara Oswald"
    assert resched["patient_phone"] == "555-8888"
    assert resched["start_time"] == "2026-10-15T14:00:00"
    assert resched["end_time"] == "2026-10-15T14:30:00"
    assert resched["status"] == "booked"

    # Old slot (09:00 - 09:30) is now completely freed up
    new_patient_appt = service_env.book_appointment(
        doctor_id=1,
        patient_name="Slot Grabber",
        patient_phone="555-7777",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00"
    )
    assert new_patient_appt["id"] is not None


def test_reschedule_rejects_conflict_with_another_appointment(service_env):
    # Appointment 1: 09:00 - 09:30
    appt1 = service_env.book_appointment(
        doctor_id=1,
        patient_name="Patient One",
        patient_phone="555-1111",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00"
    )

    # Appointment 2: 10:00 - 10:30 (blocking 10:00 slot)
    appt2 = service_env.book_appointment(
        doctor_id=1,
        patient_name="Patient Two",
        patient_phone="555-2222",
        start_time="2026-10-15T10:00:00",
        end_time="2026-10-15T10:30:00"
    )

    # Attempt to reschedule Appt 1 into Appt 2's slot (10:15 - 10:45)
    with pytest.raises(DoubleBookingConflictError) as exc:
        service_env.reschedule_appointment(
            appointment_id=appt1["id"],
            new_start_time="2026-10-15T10:15:00",
            new_end_time="2026-10-15T10:45:00"
        )
    assert "Cannot reschedule" in str(exc.value)

    # Verify Appt 1 is unmodified and still at 09:00
    unchanged = service_env.get_appointment(appt1["id"])
    assert unchanged["start_time"] == "2026-10-15T09:00:00"


def test_reschedule_excludes_self_from_overlap_check(service_env):
    # Appt 1: 09:00 - 10:00
    appt1 = service_env.book_appointment(
        doctor_id=1,
        patient_name="Shift Patient",
        patient_phone="555-3333",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T10:00:00"
    )

    # Shift by 15 min: 09:15 - 10:15 (overlaps with its own previous window)
    resched = service_env.reschedule_appointment(
        appointment_id=appt1["id"],
        new_start_time="2026-10-15T09:15:00",
        new_end_time="2026-10-15T10:15:00"
    )
    assert resched["start_time"] == "2026-10-15T09:15:00"
    assert resched["end_time"] == "2026-10-15T10:15:00"


def test_cannot_reschedule_cancelled_appointment(service_env):
    appt = service_env.book_appointment(
        doctor_id=1,
        patient_name="Cancelled Guy",
        patient_phone="555-4444",
        start_time="2026-10-15T09:00:00",
        end_time="2026-10-15T09:30:00"
    )
    service_env.cancel_appointment(appt["id"], cancellation_time="2026-10-10T09:00:00")

    with pytest.raises(ValueError) as exc:
        service_env.reschedule_appointment(
            appointment_id=appt["id"],
            new_start_time="2026-10-16T09:00:00"
        )
    assert "Cannot reschedule a cancelled appointment" in str(exc.value)
