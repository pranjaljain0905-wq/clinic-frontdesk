"""
Data models for the Clinic Front Desk System.
"""
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Optional, Dict, Any


@dataclass
class Doctor:
    id: int
    name: str
    specialty: str
    email: str
    phone: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Patient:
    id: int
    name: str
    phone: str
    email: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Appointment:
    id: int
    doctor_id: int
    patient_name: str
    patient_phone: str
    patient_email: Optional[str]
    start_time: datetime
    end_time: datetime
    status: str = "booked"  # 'booked', 'completed', 'cancelled', 'no_show'
    cancellation_fee: float = 0.0
    cancellation_reason: Optional[str] = None
    cancelled_at: Optional[datetime] = None
    notes: Optional[str] = None
    created_at: Optional[datetime] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "doctor_id": self.doctor_id,
            "patient_name": self.patient_name,
            "patient_phone": self.patient_phone,
            "patient_email": self.patient_email,
            "start_time": self.start_time.isoformat() if isinstance(self.start_time, datetime) else self.start_time,
            "end_time": self.end_time.isoformat() if isinstance(self.end_time, datetime) else self.end_time,
            "status": self.status,
            "cancellation_fee": round(float(self.cancellation_fee), 2),
            "cancellation_reason": self.cancellation_reason,
            "cancelled_at": self.cancelled_at.isoformat() if isinstance(self.cancelled_at, datetime) else self.cancelled_at,
            "notes": self.notes,
            "created_at": self.created_at.isoformat() if isinstance(self.created_at, datetime) else self.created_at,
        }


@dataclass
class OutboxNotification:
    id: int
    recipient: str
    patient_name: str
    doctor_name: str
    appointment_id: int
    date: str
    time: str
    message: str
    notification_type: str = "morning_reminder"
    created_at: Optional[datetime] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "recipient": self.recipient,
            "patient_name": self.patient_name,
            "doctor_name": self.doctor_name,
            "appointment_id": self.appointment_id,
            "date": self.date,
            "time": self.time,
            "message": self.message,
            "notification_type": self.notification_type,
            "created_at": self.created_at.isoformat() if isinstance(self.created_at, datetime) else self.created_at,
        }
