"""
Clinic Front Desk Service layer orchestrating conflict-free scheduling,
cancellation management, search, notification outbox, and no-show automation.
"""
from datetime import datetime, timedelta, date
from typing import List, Optional, Dict, Any, Union
from dateutil import parser as date_parser

from clinic.storage import Storage
from clinic.conflict import intervals_overlap, find_conflicting_appointment, DoubleBookingConflictError
from clinic.cancellation import evaluate_cancellation, DEFAULT_CUTOFF_HOURS, DEFAULT_LATE_CANCELLATION_FEE


def parse_datetime(dt_val: Union[str, datetime]) -> datetime:
    if isinstance(dt_val, datetime):
        return dt_val
    if isinstance(dt_val, str):
        return date_parser.parse(dt_val)
    raise ValueError(f"Cannot parse datetime from type {type(dt_val)}: {dt_val}")


class ClinicService:
    def __init__(self, db_path: str = "clinic.db"):
        self.storage = Storage(db_path)

    # --- Clock Management ---
    def get_clock_time(self) -> datetime:
        return self.storage.get_clock_time()

    def set_clock_time(self, dt: Union[str, datetime]) -> datetime:
        parsed_dt = parse_datetime(dt)
        self.storage.set_clock_time(parsed_dt)
        return parsed_dt

    # --- Doctors ---
    def get_doctor(self, doctor_id: int) -> Optional[Dict[str, Any]]:
        return self.storage.get_doctor(doctor_id)

    def list_doctors(self) -> List[Dict[str, Any]]:
        return self.storage.list_doctors()

    # --- Appointments: Conflict-Free Booking ---
    def book_appointment(
        self,
        doctor_id: int,
        patient_name: str,
        patient_phone: str,
        start_time: Union[str, datetime],
        end_time: Optional[Union[str, datetime]] = None,
        duration_minutes: int = 30,
        patient_email: Optional[str] = None,
        notes: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Books a new appointment for a doctor ensuring ZERO double-booking.
        
        Validation:
        1. Doctor must exist.
        2. Patient name and phone must be non-empty.
        3. Start time < End time.
        4. Overlap Check: Interval [start_time, end_time) must not overlap with any
           active appointment for this doctor.
        """
        doctor = self.storage.get_doctor(doctor_id)
        if not doctor:
            raise ValueError(f"Doctor with ID {doctor_id} does not exist.")

        patient_name = patient_name.strip() if patient_name else ""
        patient_phone = patient_phone.strip() if patient_phone else ""
        if not patient_name:
            raise ValueError("Patient name is required.")
        if not patient_phone:
            raise ValueError("Patient phone number is required.")

        parsed_start = parse_datetime(start_time)
        if end_time:
            parsed_end = parse_datetime(end_time)
        else:
            parsed_end = parsed_start + timedelta(minutes=duration_minutes)

        if parsed_start >= parsed_end:
            raise ValueError(f"Appointment start time ({parsed_start}) must be strictly before end time ({parsed_end}).")

        # Overlap verification
        existing_appts = self.storage.get_appointments_for_doctor(doctor_id, include_cancelled=False)
        conflict = find_conflicting_appointment(existing_appts, parsed_start, parsed_end)
        if conflict:
            raise DoubleBookingConflictError(
                f"Doctor {doctor['name']} already has an overlapping appointment from "
                f"{conflict['start_time']} to {conflict['end_time']} "
                f"(Appointment #{conflict['id']} with patient '{conflict['patient_name']}').",
                conflicting_appointment=conflict
            )

        # Create record
        start_iso = parsed_start.isoformat()
        end_iso = parsed_end.isoformat()
        return self.storage.create_appointment(
            doctor_id=doctor_id,
            patient_name=patient_name,
            patient_phone=patient_phone,
            patient_email=patient_email,
            start_time=start_iso,
            end_time=end_iso,
            notes=notes,
            status="booked"
        )

    # --- Fair Cancellation Rule ---
    def cancel_appointment(
        self,
        appointment_id: int,
        cancellation_time: Optional[Union[str, datetime]] = None,
        reason: Optional[str] = None,
        cutoff_hours: float = DEFAULT_CUTOFF_HOURS,
        late_fee: float = DEFAULT_LATE_CANCELLATION_FEE
    ) -> Dict[str, Any]:
        """
        Cancels an appointment fairly:
        - If cancelled >= cutoff_hours (default 24h) before start_time: FREE ($0.00).
        - If cancelled < cutoff_hours before start_time: Fair late fee assessed.
        Frees up the doctor's time slot immediately.
        """
        appt = self.storage.get_appointment(appointment_id)
        if not appt:
            raise ValueError(f"Appointment #{appointment_id} does not exist.")

        if appt["status"] == "cancelled":
            raise ValueError(f"Appointment #{appointment_id} is already cancelled.")

        if cancellation_time is None:
            cancellation_time = self.get_clock_time()
        else:
            cancellation_time = parse_datetime(cancellation_time)

        eval_res = evaluate_cancellation(
            start_time=appt["start_time"],
            cancellation_time=cancellation_time,
            cutoff_hours=cutoff_hours,
            late_fee=late_fee
        )

        final_reason = reason or eval_res["policy_description"]
        updated = self.storage.update_appointment_status(
            appointment_id=appointment_id,
            status="cancelled",
            cancellation_fee=eval_res["fee"],
            cancellation_reason=final_reason,
            cancelled_at=cancellation_time.isoformat()
        )
        updated["is_late"] = eval_res["is_late"]
        updated["policy_description"] = eval_res["policy_description"]
        return updated

    # --- Complete Appointment ---
    def complete_appointment(self, appointment_id: int) -> Dict[str, Any]:
        """Marks an appointment as completed by the doctor."""
        appt = self.storage.get_appointment(appointment_id)
        if not appt:
            raise ValueError(f"Appointment #{appointment_id} does not exist.")
        if appt["status"] == "cancelled":
            raise ValueError("Cannot complete a cancelled appointment.")
        return self.storage.update_appointment_status(appointment_id, status="completed")

    # --- Level 1 ? T6 (lifecycle): Reschedule Appointment ---
    def reschedule_appointment(
        self,
        appointment_id: int,
        new_start_time: Union[str, datetime],
        new_end_time: Optional[Union[str, datetime]] = None,
        duration_minutes: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Level 1 Twist: Reschedules an existing appointment to a new time.
        Rules:
        - Keeps the same patient and doctor invariant.
        - Must stay conflict-free (re-checks overlap against doctor's schedule).
        - Excludes the appointment itself from the overlap collision detection.
        - Cannot reschedule a cancelled appointment.
        """
        appt = self.storage.get_appointment(appointment_id)
        if not appt:
            raise ValueError(f"Appointment #{appointment_id} does not exist.")

        if appt["status"] == "cancelled":
            raise ValueError("Cannot reschedule a cancelled appointment.")

        doctor_id = appt["doctor_id"]
        doctor_name = appt["doctor_name"]

        parsed_new_start = parse_datetime(new_start_time)
        if new_end_time:
            parsed_new_end = parse_datetime(new_end_time)
        elif duration_minutes:
            parsed_new_end = parsed_new_start + timedelta(minutes=duration_minutes)
        else:
            # Preserve original appointment duration
            orig_start = parse_datetime(appt["start_time"])
            orig_end = parse_datetime(appt["end_time"])
            orig_duration = orig_end - orig_start
            parsed_new_end = parsed_new_start + orig_duration

        if parsed_new_start >= parsed_new_end:
            raise ValueError(f"Rescheduled start time ({parsed_new_start}) must be before end time ({parsed_new_end}).")

        # Overlap check strictly excluding this appointment itself
        existing_appts = self.storage.get_appointments_for_doctor(doctor_id, include_cancelled=False)
        conflict = find_conflicting_appointment(
            existing_appts,
            parsed_new_start,
            parsed_new_end,
            exclude_appointment_id=appointment_id
        )

        if conflict:
            raise DoubleBookingConflictError(
                f"Cannot reschedule: Doctor {doctor_name} is already booked from "
                f"{conflict['start_time']} to {conflict['end_time']} "
                f"(Appointment #{conflict['id']} with '{conflict['patient_name']}').",
                conflicting_appointment=conflict
            )

        # Update times and re-confirm status
        updated = self.storage.reschedule_appointment(
            appointment_id=appointment_id,
            new_start_time=parsed_new_start.isoformat(),
            new_end_time=parsed_new_end.isoformat()
        )
        return updated

    # --- Lookups: Doctor's Day View ---
    def get_doctor_day(self, doctor_id: int, target_date: Union[str, date]) -> Dict[str, Any]:
        """
        Desk View: Returns a doctor's full day schedule with summary metrics.
        """
        doctor = self.storage.get_doctor(doctor_id)
        if not doctor:
            raise ValueError(f"Doctor #{doctor_id} not found.")

        date_str = target_date.isoformat() if isinstance(target_date, (date, datetime)) else str(target_date)[:10]
        appts = self.storage.get_doctor_day_appointments(doctor_id, date_str)

        booked = [a for a in appts if a["status"] == "booked"]
        completed = [a for a in appts if a["status"] == "completed"]
        cancelled = [a for a in appts if a["status"] == "cancelled"]
        no_show = [a for a in appts if a["status"] == "no_show"]
        total_fees = sum(a.get("cancellation_fee", 0.0) for a in cancelled)

        return {
            "doctor": doctor,
            "date": date_str,
            "appointments": appts,
            "stats": {
                "total": len(appts),
                "booked": len(booked),
                "completed": len(completed),
                "cancelled": len(cancelled),
                "no_show": len(no_show),
                "cancellation_fees_collected": round(total_fees, 2)
            }
        }

    # --- Lookups: Patient Appointment Search by Name ---
    def search_patient_appointments(self, query: str) -> List[Dict[str, Any]]:
        """Desk View: Searches patient appointments by name (case-insensitive substring)."""
        if not query or not query.strip():
            return []
        return self.storage.search_appointments_by_patient_name(query)

    # --- Lookups: General List ---
    def list_appointments(
        self,
        doctor_id: Optional[int] = None,
        date_str: Optional[str] = None,
        status: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        return self.storage.list_appointments(doctor_id, date_str, status)

    def get_appointment(self, appointment_id: int) -> Optional[Dict[str, Any]]:
        return self.storage.get_appointment(appointment_id)

    # --- Level 2 (integrate) & Level 3 (automation): Clock Tick ---
    def tick_clock(
        self,
        target_date: Optional[Union[str, date]] = None,
        timestamp: Optional[Union[str, datetime]] = None,
        time_str: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Advances or sets the clinic clock, executing:
        1. Level 2 (T1): Morning reminders into /outbox for today's active appointments.
        2. Level 3 (T2): Auto-marks appointments as no-show 30 min after start if not completed.
        """
        # Determine simulated clock datetime
        if timestamp is not None:
            simulated_now = parse_datetime(timestamp)
        elif target_date is not None and time_str is not None:
            simulated_now = parse_datetime(f"{target_date}T{time_str}")
        elif target_date is not None:
            # If only date is provided, default morning check at 08:00 AM
            d_str = target_date.isoformat() if isinstance(target_date, (date, datetime)) else str(target_date)[:10]
            simulated_now = parse_datetime(f"{d_str}T08:00:00")
        else:
            simulated_now = self.get_clock_time() + timedelta(hours=1)

        self.storage.set_clock_time(simulated_now)
        date_key = simulated_now.strftime("%Y-%m-%d")

        # -------------------------------------------------------------
        # Level 2 ? T1 (integrate): Morning Reminders via Notification Outbox
        # -------------------------------------------------------------
        dispatched_reminders = []
        todays_appts = self.storage.list_appointments(date_str=date_key, status="booked")
        for appt in todays_appts:
            if not self.storage.has_morning_reminder(appt["id"], date_key):
                start_dt = parse_datetime(appt["start_time"])
                formatted_time = start_dt.strftime("%H:%M")
                msg = (
                    f"Good morning {appt['patient_name']}, this is a friendly reminder "
                    f"for your appointment with {appt['doctor_name']} today at {formatted_time}."
                )
                entry = self.storage.add_outbox_notification(
                    recipient=appt["patient_phone"],
                    patient_name=appt["patient_name"],
                    doctor_name=appt["doctor_name"],
                    appointment_id=appt["id"],
                    date_str=date_key,
                    time_str=formatted_time,
                    message=msg,
                    notification_type="morning_reminder"
                )
                dispatched_reminders.append(entry)

        # -------------------------------------------------------------
        # Level 3 ? T2 (automation): Auto-mark No-Show 30 min after start
        # -------------------------------------------------------------
        no_shows_marked = []
        # Check all booked appointments
        all_booked = self.storage.list_appointments(status="booked")
        for appt in all_booked:
            appt_start = parse_datetime(appt["start_time"])
            # If 30 minutes or more have elapsed since start time
            if simulated_now >= appt_start + timedelta(minutes=30):
                self.storage.update_appointment_status(
                    appointment_id=appt["id"],
                    status="no_show",
                    cancellation_reason="Automated: Patient did not attend within 30 minutes of appointment start time."
                )
                no_shows_marked.append(appt["id"])

        outbox_items = self.storage.get_outbox()

        return {
            "success": True,
            "clock_time": simulated_now.isoformat(),
            "date": date_key,
            "reminders_dispatched": len(dispatched_reminders),
            "new_reminders": dispatched_reminders,
            "no_shows_marked": len(no_shows_marked),
            "no_show_appointment_ids": no_shows_marked,
            "outbox": outbox_items,
            "dispatched_count": len(dispatched_reminders)
        }

    # --- Outbox Queries ---
    def get_outbox(self, date_str: Optional[str] = None, recipient: Optional[str] = None) -> List[Dict[str, Any]]:
        return self.storage.get_outbox(date_str=date_str, recipient=recipient)

    def clear_outbox(self):
        self.storage.clear_outbox()

    # --- Overall Clinic Stats ---
    def get_clinic_stats(self) -> Dict[str, Any]:
        all_appts = self.storage.list_appointments()
        booked = [a for a in all_appts if a["status"] == "booked"]
        completed = [a for a in all_appts if a["status"] == "completed"]
        cancelled = [a for a in all_appts if a["status"] == "cancelled"]
        no_show = [a for a in all_appts if a["status"] == "no_show"]
        total_fees = sum(a.get("cancellation_fee", 0.0) for a in cancelled)

        return {
            "total_appointments": len(all_appts),
            "booked": len(booked),
            "completed": len(completed),
            "cancelled": len(cancelled),
            "no_show": len(no_show),
            "total_cancellation_fees": round(total_fees, 2),
            "doctors_count": len(self.storage.list_doctors())
        }
