"""
Fair cancellation policy engine.
Calculates fees based on lead time before the appointment start time.
"""
from datetime import datetime, timedelta
from typing import Dict, Any, Optional

DEFAULT_CUTOFF_HOURS: float = 24.0
DEFAULT_LATE_CANCELLATION_FEE: float = 25.00


def evaluate_cancellation(
    start_time: datetime,
    cancellation_time: Optional[datetime] = None,
    cutoff_hours: float = DEFAULT_CUTOFF_HOURS,
    late_fee: float = DEFAULT_LATE_CANCELLATION_FEE
) -> Dict[str, Any]:
    """
    Evaluates whether a cancellation is eligible for free cancellation or incurs a late fee.
    
    Rule:
    - Delta = start_time - cancellation_time
    - If Delta >= cutoff_hours:
        Fee = $0.00 (On-time, fair free cancellation)
    - If Delta < cutoff_hours:
        Fee = late_fee (Late cancellation fee applies)
        
    Returns:
        Dict with keys:
            - is_late: bool
            - fee: float
            - hours_before_start: float
            - policy_description: str
    """
    if cancellation_time is None:
        cancellation_time = datetime.now()
        
    if isinstance(start_time, str):
        start_time = datetime.fromisoformat(start_time.replace("Z", ""))
    if isinstance(cancellation_time, str):
        cancellation_time = datetime.fromisoformat(cancellation_time.replace("Z", ""))
        
    delta = start_time - cancellation_time
    hours_before = delta.total_seconds() / 3600.0
    
    if hours_before >= cutoff_hours:
        return {
            "is_late": False,
            "fee": 0.0,
            "hours_before_start": round(hours_before, 2),
            "policy_description": f"On-time cancellation: Cancelled {round(hours_before, 1)}h in advance (threshold is {cutoff_hours}h). No fee assessed."
        }
    else:
        return {
            "is_late": True,
            "fee": round(late_fee, 2),
            "hours_before_start": round(hours_before, 2),
            "policy_description": f"Late cancellation: Cancelled {round(hours_before, 1)}h before appointment (less than {cutoff_hours}h notice). Fair fee of ${late_fee:.2f} applied."
        }
