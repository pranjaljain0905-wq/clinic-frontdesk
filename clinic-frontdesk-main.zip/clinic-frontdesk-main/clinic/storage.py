"""
Transactional SQLite storage repository for clinic front desk operations.
"""
import sqlite3
from datetime import datetime
from typing import List, Optional, Dict, Any


DEFAULT_DOCTORS = [
    {"id": 1, "name": "Dr. Sarah Jenkins", "specialty": "Cardiology", "email": "s.jenkins@clinic.org", "phone": "555-0101"},
    {"id": 2, "name": "Dr. Robert Chen", "specialty": "General Medicine", "email": "r.chen@clinic.org", "phone": "555-0102"},
    {"id": 3, "name": "Dr. Priya Patel", "specialty": "Pediatrics", "email": "p.patel@clinic.org", "phone": "555-0103"},
    {"id": 4, "name": "Dr. Marcus Vance", "specialty": "Orthopedics", "email": "m.vance@clinic.org", "phone": "555-0104"},
]


class Storage:
    def __init__(self, db_path: str = "clinic.db"):
        self.db_path = db_path
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        if self.db_path == ":memory:":
            if not hasattr(self, "_memory_conn") or self._memory_conn is None:
                self._memory_conn = sqlite3.connect(":memory:", check_same_thread=False)
                self._memory_conn.row_factory = sqlite3.Row
                self._memory_conn.execute("PRAGMA foreign_keys = ON;")
            return self._memory_conn
            
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    def _init_db(self):
        with self._get_connection() as conn:
            # 1. Doctors table
            conn.execute("""
            CREATE TABLE IF NOT EXISTS doctors (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                specialty TEXT NOT NULL,
                email TEXT NOT NULL,
                phone TEXT NOT NULL
            );
            """)

            # 2. Appointments table
            conn.execute("""
            CREATE TABLE IF NOT EXISTS appointments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                doctor_id INTEGER NOT NULL,
                patient_name TEXT NOT NULL,
                patient_phone TEXT NOT NULL,
                patient_email TEXT,
                start_time TEXT NOT NULL,
                end_time TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'booked',
                cancellation_fee REAL DEFAULT 0.0,
                cancellation_reason TEXT,
                cancelled_at TEXT,
                notes TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(doctor_id) REFERENCES doctors(id)
            );
            """)

            # 3. Notification Outbox (Level 2 ? T1)
            conn.execute("""
            CREATE TABLE IF NOT EXISTS outbox (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                recipient TEXT NOT NULL,
                patient_name TEXT NOT NULL,
                doctor_name TEXT NOT NULL,
                appointment_id INTEGER NOT NULL,
                date TEXT NOT NULL,
                time TEXT NOT NULL,
                message TEXT NOT NULL,
                notification_type TEXT NOT NULL DEFAULT 'morning_reminder',
                created_at TEXT NOT NULL
            );
            """)

            # 4. Clock state
            conn.execute("""
            CREATE TABLE IF NOT EXISTS clock_state (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                current_time TEXT NOT NULL
            );
            """)

            # Indices
            conn.execute("""CREATE INDEX IF NOT EXISTS idx_appt_doc ON appointments(doctor_id, start_time);""")
            conn.execute("""CREATE INDEX IF NOT EXISTS idx_appt_pat ON appointments(patient_name);""")
            conn.execute("""CREATE INDEX IF NOT EXISTS idx_appt_status ON appointments(status);""")
            conn.execute("""CREATE INDEX IF NOT EXISTS idx_outbox_date ON outbox(date);""")

            # Seed default doctors if table is empty
            cur = conn.execute("""SELECT COUNT(*) as cnt FROM doctors;""")
            if cur.fetchone()["cnt"] == 0:
                for doc in DEFAULT_DOCTORS:
                    conn.execute(
                        """INSERT INTO doctors (id, name, specialty, email, phone) VALUES (?, ?, ?, ?, ?);""",
                        (doc["id"], doc["name"], doc["specialty"], doc["email"], doc["phone"])
                    )

            # Seed initial clock state if empty
            cur_clock = conn.execute("""SELECT COUNT(*) as cnt FROM clock_state;""")
            if cur_clock.fetchone()["cnt"] == 0:
                conn.execute(
                    """INSERT INTO clock_state (id, current_time) VALUES (1, ?);""",
                    (datetime.now().isoformat(),)
                )

            conn.commit()

    # --- Doctors ---
    def get_doctor(self, doctor_id: int) -> Optional[Dict[str, Any]]:
        with self._get_connection() as conn:
            row = conn.execute("""SELECT * FROM doctors WHERE id = ?;""", (doctor_id,)).fetchone()
            return dict(row) if row else None

    def list_doctors(self) -> List[Dict[str, Any]]:
        with self._get_connection() as conn:
            rows = conn.execute("""SELECT * FROM doctors ORDER BY id ASC;""").fetchall()
            return [dict(r) for r in rows]

    # --- Appointments ---
    def create_appointment(
        self,
        doctor_id: int,
        patient_name: str,
        patient_phone: str,
        patient_email: Optional[str],
        start_time: str,
        end_time: str,
        notes: Optional[str] = None,
        status: str = "booked"
    ) -> Dict[str, Any]:
        now_str = datetime.now().isoformat()
        with self._get_connection() as conn:
            cur = conn.execute(
                """
                INSERT INTO appointments (
                    doctor_id, patient_name, patient_phone, patient_email,
                    start_time, end_time, status, notes, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
                """,
                (doctor_id, patient_name, patient_phone, patient_email, start_time, end_time, status, notes, now_str)
            )
            appt_id = cur.lastrowid
            conn.commit()
            return self.get_appointment(appt_id)

    def get_appointment(self, appointment_id: int) -> Optional[Dict[str, Any]]:
        with self._get_connection() as conn:
            row = conn.execute(
                """
                SELECT a.*, d.name as doctor_name, d.specialty as doctor_specialty
                FROM appointments a
                JOIN doctors d ON a.doctor_id = d.id
                WHERE a.id = ?;
                """,
                (appointment_id,)
            ).fetchone()
            return dict(row) if row else None

    def get_appointments_for_doctor(
        self,
        doctor_id: int,
        start_time_min: Optional[str] = None,
        start_time_max: Optional[str] = None,
        include_cancelled: bool = False
    ) -> List[Dict[str, Any]]:
        query = """SELECT * FROM appointments WHERE doctor_id = ?"""
        params = [doctor_id]

        if not include_cancelled:
            query += """ AND status != 'cancelled'"""

        if start_time_min:
            query += """ AND start_time >= ?"""
            params.append(start_time_min)

        if start_time_max:
            query += """ AND start_time <= ?"""
            params.append(start_time_max)

        query += """ ORDER BY start_time ASC;"""

        with self._get_connection() as conn:
            rows = conn.execute(query, params).fetchall()
            return [dict(r) for r in rows]

    def get_doctor_day_appointments(self, doctor_id: int, date_str: str) -> List[Dict[str, Any]]:
        """Finds all appointments for a doctor on a specific date (YYYY-MM-DD)."""
        start_bound = f"{date_str}T00:00:00"
        end_bound = f"{date_str}T23:59:59"
        with self._get_connection() as conn:
            rows = conn.execute(
                """
                SELECT a.*, d.name as doctor_name, d.specialty as doctor_specialty
                FROM appointments a
                JOIN doctors d ON a.doctor_id = d.id
                WHERE a.doctor_id = ?
                  AND a.start_time >= ?
                  AND a.start_time <= ?
                ORDER BY a.start_time ASC;
                """,
                (doctor_id, start_bound, end_bound)
            ).fetchall()
            return [dict(r) for r in rows]

    def search_appointments_by_patient_name(self, name_query: str) -> List[Dict[str, Any]]:
        """Case-insensitive substring search for patient appointments by name."""
        pattern = f"%{name_query.strip().lower()}%"
        with self._get_connection() as conn:
            rows = conn.execute(
                """
                SELECT a.*, d.name as doctor_name, d.specialty as doctor_specialty
                FROM appointments a
                JOIN doctors d ON a.doctor_id = d.id
                WHERE LOWER(a.patient_name) LIKE ?
                ORDER BY a.start_time DESC;
                """,
                (pattern,)
            ).fetchall()
            return [dict(r) for r in rows]

    def list_appointments(
        self,
        doctor_id: Optional[int] = None,
        date_str: Optional[str] = None,
        status: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        query = """
        SELECT a.*, d.name as doctor_name, d.specialty as doctor_specialty
        FROM appointments a
        JOIN doctors d ON a.doctor_id = d.id
        WHERE 1=1
        """
        params = []

        if doctor_id:
            query += """ AND a.doctor_id = ?"""
            params.append(doctor_id)

        if date_str:
            query += """ AND a.start_time >= ? AND a.start_time <= ?"""
            params.extend([f"{date_str}T00:00:00", f"{date_str}T23:59:59"])

        if status:
            query += """ AND a.status = ?"""
            params.append(status)

        query += """ ORDER BY a.start_time ASC;"""

        with self._get_connection() as conn:
            rows = conn.execute(query, params).fetchall()
            return [dict(r) for r in rows]

    def update_appointment_status(
        self,
        appointment_id: int,
        status: str,
        cancellation_fee: float = 0.0,
        cancellation_reason: Optional[str] = None,
        cancelled_at: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        with self._get_connection() as conn:
            conn.execute(
                """
                UPDATE appointments
                SET status = ?,
                    cancellation_fee = ?,
                    cancellation_reason = ?,
                    cancelled_at = ?
                WHERE id = ?;
                """,
                (status, cancellation_fee, cancellation_reason, cancelled_at, appointment_id)
            )
            conn.commit()
            return self.get_appointment(appointment_id)

    def reschedule_appointment(
        self,
        appointment_id: int,
        new_start_time: str,
        new_end_time: str
    ) -> Optional[Dict[str, Any]]:
        """Updates start and end times for an existing appointment, resetting status to 'booked' if needed."""
        with self._get_connection() as conn:
            conn.execute(
                """
                UPDATE appointments
                SET start_time = ?,
                    end_time = ?,
                    status = 'booked'
                WHERE id = ?;
                """,
                (new_start_time, new_end_time, appointment_id)
            )
            conn.commit()
            return self.get_appointment(appointment_id)

    # --- Outbox (Level 2 Notification Service) ---
    def add_outbox_notification(
        self,
        recipient: str,
        patient_name: str,
        doctor_name: str,
        appointment_id: int,
        date_str: str,
        time_str: str,
        message: str,
        notification_type: str = "morning_reminder"
    ) -> Dict[str, Any]:
        now_str = datetime.now().isoformat()
        with self._get_connection() as conn:
            cur = conn.execute(
                """
                INSERT INTO outbox (
                    recipient, patient_name, doctor_name, appointment_id,
                    date, time, message, notification_type, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
                """,
                (recipient, patient_name, doctor_name, appointment_id, date_str, time_str, message, notification_type, now_str)
            )
            outbox_id = cur.lastrowid
            conn.commit()
            row = conn.execute("""SELECT * FROM outbox WHERE id = ?;""", (outbox_id,)).fetchone()
            return dict(row)

    def get_outbox(
        self,
        date_str: Optional[str] = None,
        recipient: Optional[str] = None,
        notification_type: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        query = """SELECT * FROM outbox WHERE 1=1"""
        params = []
        if date_str:
            query += """ AND date = ?"""
            params.append(date_str)
        if recipient:
            query += """ AND recipient = ?"""
            params.append(recipient)
        if notification_type:
            query += """ AND notification_type = ?"""
            params.append(notification_type)
        query += """ ORDER BY id ASC;"""

        with self._get_connection() as conn:
            rows = conn.execute(query, params).fetchall()
            return [dict(r) for r in rows]

    def has_morning_reminder(self, appointment_id: int, date_str: str) -> bool:
        with self._get_connection() as conn:
            row = conn.execute(
                """
                SELECT id FROM outbox
                WHERE appointment_id = ?
                  AND date = ?
                  AND notification_type = 'morning_reminder';
                """,
                (appointment_id, date_str)
            ).fetchone()
            return row is not None

    def clear_outbox(self):
        with self._get_connection() as conn:
            conn.execute("""DELETE FROM outbox;""")
            conn.commit()

    # --- Clock State ---
    def get_clock_time(self) -> datetime:
        with self._get_connection() as conn:
            row = conn.execute("""SELECT current_time FROM clock_state WHERE id = 1;""").fetchone()
            if row and row["current_time"]:
                val = str(row["current_time"]).strip()
                try:
                    return datetime.fromisoformat(val)
                except Exception:
                    try:
                        from dateutil import parser as date_parser
                        return date_parser.parse(val)
                    except Exception:
                        pass
            return datetime.now()

    def set_clock_time(self, dt: Any):
        if isinstance(dt, str):
            try:
                dt = datetime.fromisoformat(dt)
            except Exception:
                from dateutil import parser as date_parser
                dt = date_parser.parse(dt)
        with self._get_connection() as conn:
            conn.execute(
                """UPDATE clock_state SET current_time = ? WHERE id = 1;""",
                (dt.isoformat(),)
            )
            conn.commit()
