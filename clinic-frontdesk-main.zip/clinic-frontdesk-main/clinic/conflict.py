"""
Conflict detection and mathematical interval overlap calculations for doctor scheduling.
"""
from datetime import datetime
from typing import List, Optional, Tuple, Any


class DoubleBookingConflictError(Exception):
    """Raised when an appointment conflicts with an existing appointment for the same doctor."""
    def __init__(self, message: str, conflicting_appointment: Any = None):
        super().__init__(message)
        self.conflicting_appointment = conflicting_appointment


def intervals_overlap(start1: datetime, end1: datetime, start2: datetime, end2: datetime) -> bool:
    """
    Determines whether two half-open intervals [start1, end1) and [start2, end2) overlap.
    
    Mathematical Formulation:
        Two intervals [s1, e1) and [s2, e2) overlap if and only if:
            s1 < e2  AND  s2 < e1
        Equivalently:
            max(s1, s2) < min(e1, e2)
            
    Touching at the boundary (e.g. e1 == s2 or e2 == s1) does NOT constitute an overlap;
    back-to-back appointments (e.g. 09:00-09:30 and 09:30-10:00) are explicitly permitted.
    
    Raises:
        ValueError: If start is greater than or equal to end for either interval.
    """
    if start1 >= end1:
        raise ValueError(f"Interval 1 start time ({start1}) must be strictly before end time ({end1})")
    if start2 >= end2:
        raise ValueError(f"Interval 2 start time ({start2}) must be strictly before end time ({end2})")

    return (start1 < end2) and (start2 < end1)


def find_conflicting_appointment(
    existing_appointments: List[Any],
    new_start: datetime,
    new_end: datetime,
    exclude_appointment_id: Optional[int] = None
) -> Optional[Any]:
    """
    Searches a list of appointments for any appointment that overlaps with [new_start, new_end).
    
    Excludes:
    - Appointments with status == 'cancelled'
    - The appointment with ID == exclude_appointment_id (crucial for Level 1 Reschedule)
    
    Returns:
        The first conflicting appointment object/dict found, or None if the slot is clear.
    """
    for appt in existing_appointments:
        # Handle dict or dataclass/object
        appt_id = appt.get("id") if isinstance(appt, dict) else getattr(appt, "id", None)
        status = appt.get("status") if isinstance(appt, dict) else getattr(appt, "status", None)
        
        if exclude_appointment_id is not None and appt_id == exclude_appointment_id:
            continue
            
        if status == "cancelled":
            continue
            
        start = appt.get("start_time") if isinstance(appt, dict) else getattr(appt, "start_time")
        end = appt.get("end_time") if isinstance(appt, dict) else getattr(appt, "end_time")
        
        if isinstance(start, str):
            start = datetime.fromisoformat(start.replace("Z", ""))
        if isinstance(end, str):
            end = datetime.fromisoformat(end.replace("Z", ""))
            
        if intervals_overlap(new_start, new_end, start, end):
            return appt
            
    return None
